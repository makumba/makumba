This is the test corpus for MDD files.
Each root directory represents one application. The MDD files are located in WEB-INF/classes/dataDefinitions as long as there is no better configurable finding mechanism.
