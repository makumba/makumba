import antlr.CommonAST;
import java.io.*;

public class PascalAST extends CommonAST implements Serializable {
  Symbol symbol;

  public PascalAST() {
  }
}
