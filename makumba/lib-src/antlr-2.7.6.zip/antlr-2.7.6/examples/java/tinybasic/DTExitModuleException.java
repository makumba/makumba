package tinybasic;

//import antlr.ParserException;

public class DTExitModuleException extends DTExecException{


	public DTExitModuleException(String s){
		super(s);
	}

}
