/** Test homogeneous class */
public class MyAST extends antlr.CommonAST {
}
