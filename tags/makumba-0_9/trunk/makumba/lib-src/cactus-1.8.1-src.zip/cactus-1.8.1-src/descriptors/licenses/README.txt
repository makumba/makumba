This directory contains the union of all the licenses used by the
Cactus and third party software.

ServletAPI - Apache 2.0
AspectJ - Mozilla 1.1
HttpUnit - HttpUnit specific license
Jetty - Apache 2.0
Apache Cactus - Apache 2.0
Apache Commons Logging - Apache 2.0
Apache Commons HttpClient - Apache 2.0
Jasper Compiler - Apache 2.0
Jasper Runtime - Apache 2.0
JUnit - Common Public License v1.0
NekoHtml - Apache 2.0
Cargo UberJar & Cargo-Ant integration - Apache 2.0
