package org.hibernate.loader.custom;

/**
 * Represents a return in a custom query.
 *
 * @author Steve Ebersole
 */
public interface Return {
}
