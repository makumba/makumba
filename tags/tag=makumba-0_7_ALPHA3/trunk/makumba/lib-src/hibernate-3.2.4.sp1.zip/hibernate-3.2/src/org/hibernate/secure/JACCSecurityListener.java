package org.hibernate.secure;

/**
 * Marker interface for JACC event listeners
 * 
 * @author <a href="kabir.khan@jboss.com">Kabir Khan</a>
 * @version $Revision: 8702 $
 */
public interface JACCSecurityListener{

}
